// server/api/payments/paypal-capture.post.js
import { defineEventHandler, readBody } from "h3";
import { useRuntimeConfig } from "#imports";
import { Buffer } from "node:buffer";

// ⚙️ util DB (adapte le chemin si besoin)
import { getConnection } from "../../utils/db.config";

// ⚙️ ton util d’auth réel
import { getUserFromCookie } from "../../utils/authSession.js";

async function getPaypalAccessToken(cfg) {
  const clientId = cfg.paypalClientId;
  const secret = cfg.paypalSecret;
  const env = cfg.paypalEnv || "sandbox";

  if (!clientId || !secret) {
    throw new Error("PayPal credentials missing");
  }

  const baseUrl =
    env === "live"
      ? "https://api-m.paypal.com"
      : "https://api-m.sandbox.paypal.com";

  const res = await fetch(`${baseUrl}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization:
        "Basic " + Buffer.from(`${clientId}:${secret}`).toString("base64"),
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`PayPal token error: ${res.status} – ${text}`);
  }

  const json = await res.json();
  return {
    accessToken: json.access_token,
    baseUrl,
  };
}

async function getPaypalOrderDetails(orderId, cfg) {
  const { accessToken, baseUrl } = await getPaypalAccessToken(cfg);

  const res = await fetch(`${baseUrl}/v2/checkout/orders/${orderId}`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`PayPal order error: ${res.status} – ${text}`);
  }

  return res.json();
}

export default defineEventHandler(async (event) => {
  const cfg = useRuntimeConfig(); // private runtime config (paypalClientId, etc.)

  const body = await readBody(event);
  const {
    orderId,
    amount, // indicatif (on fera confiance à PayPal en priorité)
    currency,
    anonymous = false,
    donorEmail = null,
    raw = null,
  } = body || {};

  if (!orderId) {
    event.node.res.statusCode = 400;
    return { ok: false, error: "MISSING_ORDER_ID" };
  }

  // 🌐 On vérifie l’ordre chez PayPal (source de vérité)
  let order;
  try {
    order = await getPaypalOrderDetails(orderId, cfg);
  } catch (err) {
    console.error("PayPal verification failed:", err);
    event.node.res.statusCode = 502;
    return { ok: false, error: "PAYPAL_VERIFICATION_FAILED" };
  }

  const status = order.status;
  const purchaseUnit = order.purchase_units?.[0];
  const paypalAmount = purchaseUnit?.amount?.value;
  const paypalCurrency =
    purchaseUnit?.amount?.currency_code || currency || "EUR";

  if (status !== "COMPLETED" && status !== "APPROVED") {
    event.node.res.statusCode = 400;
    return { ok: false, error: "ORDER_NOT_COMPLETED", status };
  }

  // 💶 Montant final = ce que PayPal a vu (sinon fallback sur ce que le front a envoyé)
  const finalAmount = paypalAmount
    ? Number.parseFloat(paypalAmount)
    : amount
    ? Number.parseFloat(amount)
    : null;

  // 👤 On regarde si quelqu’un est connecté (cookie JWT)
  let userId = null;
  try {
    const cookieUser = getUserFromCookie(event);
    if (cookieUser?.id) {
      userId = cookieUser.id;
    }
  } catch (err) {
    console.warn("PayPal capture: getUserFromCookie failed:", err);
  }

  // 🗂 Connexion MySQL
  const conn = await getConnection();

  try {
    // 🔁 On évite les doublons sur la même transaction PayPal
    const [existing] = await conn.query(
      "SELECT donation_id FROM donations WHERE provider = ? AND provider_payment_id = ? LIMIT 1",
      ["paypal", orderId]
    );

    if (Array.isArray(existing) && existing.length > 0) {
      return { ok: true, duplicate: true };
    }

    // 📝 meta JSON (utile pour l’admin + debug)
    const metaJson = JSON.stringify({
      fromClient: raw || null,
      paypalOrder: order,
    });

    // 🧾 Insertion dans la table donations
    // adapte les colonnes si ta table est différente
    await conn.query(
      `
        INSERT INTO donations (
          provider,
          provider_payment_id,
          amount,
          currency,
          anonymous,
          donor_email,
          user_id,
          meta,
          created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
      `,
      [
        "paypal",
        orderId,
        finalAmount,
        paypalCurrency,
        anonymous ? 1 : 0,
        donorEmail || order.payer?.email_address || null,
        userId,
        metaJson,
      ]
    );

    return { ok: true };
  } catch (err) {
    console.error("PayPal capture DB error:", err);
    event.node.res.statusCode = 500;
    return { ok: false, error: "DB_ERROR" };
  } finally {
    try {
      await conn.release();
    } catch {}
  }
});
