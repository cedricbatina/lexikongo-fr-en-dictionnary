export default defineEventHandler(() => {
  return { ok: true, message: "pong from Nitro" };
});
